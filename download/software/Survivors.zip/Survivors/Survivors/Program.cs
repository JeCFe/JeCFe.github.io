﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;


namespace survivors
{
    class Program
    {

        //Global variables

        private static int Weeks = 0;
        private static int Survivors = 10;
        private static int Resources = 1500;
        private static int AntiRadKits = 1;
        private static int LostResources = 0;
        private static int FoundResources = 0;
        private static int FoundPeople = 0;
        private static int PeopleLost = 0;
        private static int Deaths = 0;

        private static int TeamAmount;

        //Bool variables used in game
        private static bool bGamePlay = true;
        private static bool bTestResourceFeed = false;
        private static bool bTestPopExplore;
        private static bool bTestAntiRad;
        private static bool bRadationPlume = false;
        private static bool bNothing;

        static void Main(string[] args)
        {

            Console.ForegroundColor = ConsoleColor.DarkGreen; //Sets text colour to green
            Console.SetWindowSize(85, 40);  //resizes console window size



            bool Input = false;
            while (Input == false)   //For loop to ensure that value entered is correct 
            {
                Console.WriteLine("Rules? Y/N");
                string TestInput = Console.ReadLine();
                TestInput = TestInput.ToUpper();
                if (TestInput == "Y")   //If the user entered Y then the rules will be displayed
                {
                    Console.WriteLine("     ██████╗ ██╗   ██╗██╗     ███████╗███████╗   ");
                    Console.WriteLine("     ██╔══██╗██║   ██║██║     ██╔════╝██╔════╝██╗");
                    Console.WriteLine("     ██████╔╝██║   ██║██║     █████╗  ███████╗╚═╝");
                    Console.WriteLine("     ██╔══██╗██║   ██║██║     ██╔══╝  ╚════██║██╗");
                    Console.WriteLine("     ██║  ██║╚██████╔╝███████╗███████╗███████║╚═╝");
                    Console.WriteLine("     ╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚══════╝╚══════╝   ");
                    Console.WriteLine("\n\n1. Each games last for 10 weeks, or until everyone dies. Each round is 1 week.");
                    Console.WriteLine("2. Each person requires 100 resources to survive the week.");
                    Console.WriteLine("3. You will be able to send out scavenging  missions.");
                    Console.WriteLine("3a.  Each scavenging mission requires 2 people.");
                    Console.WriteLine("3b.  Each 2 team will require 50 resources.");
                    Console.WriteLine("3c.  If nobody is left at base then game is over");
                    Console.WriteLine("4. Scavenging missions has the potential to find resources and people.");
                    Console.WriteLine("5. Anti radiation kits can be used to cure your population from radiation sickness");
                    Console.WriteLine("5a.  1 kit cures 1 person.");
                    Console.WriteLine();
                    Input = true;
                }
                if (TestInput == "N")   //If user entered N then the rules wont be displayed and the game
                {
                    Input = true;
                }
                //If the input was fasle the question will repeat
            }


            //Start of the game

            Console.ForegroundColor = ConsoleColor.DarkGreen; //Sets text colour to green

            //Give the lore of the game
            Console.WriteLine("\n\n\nYou with 9 other survivors have survived a nuclear explosion.\nThis explosion was an accidental misfire from the UK Navy");
            Console.WriteLine("You with the other survivors have found a nuclear bunker");
            Console.WriteLine("You have limited resources.\n10 weeks until help arrives.\nThe surface is in a state of chaos");
            Console.WriteLine("Will. You. Survive?");
            Console.WriteLine("\n\n\n\n\n\n\nPress enter key to continue");
            Console.ReadLine();
            Console.Clear();

            //Main Game Loop
            while (bGamePlay == true && Weeks != 10)
            {
                try
                {
                    if (Survivors <= 0)
                    {
                        Game_Over(5);
                    }
                    Random RandomInt = new Random(); //Generates random valuews
                    Random RandomWastedResources = new Random(); //Generates random value

                    int WastedResources = RandomWastedResources.Next(1, 100);   //Used to generated random amount of resources that are gone
                    if (Weeks >= 1)
                    {


                        if (WastedResources <= 50)
                        {

                            //This gives a random reason for those resources to have vanished
                            int ReasonMissing = RandomInt.Next(1, 5);
                            Console.ForegroundColor = ConsoleColor.DarkRed;
                            int AmountMissing = Resources / 2;
                            switch (ReasonMissing)
                            {

                                case 1:
                                    {
                                        //Half of resources are gone
                                        Console.WriteLine(AmountMissing + ": Has been stolen from your supplies.");
                                        Resources = Resources / 2;
                                        break;
                                    }
                                case 2:
                                    {
                                        //If this happens then half of resources are gone
                                        Console.WriteLine(AmountMissing + ": Has expired from your supplies.");
                                        Resources = Resources / 2;
                                        break;
                                    }
                                case 3:
                                    {
                                        //If this case happens then half of resources, and 1 survivor is gone
                                        Console.WriteLine("One of your fellow survivors have stolen " + AmountMissing + " resources.");
                                        Console.WriteLine("They have paid for it with their life");
                                        Resources = Resources / 2;
                                        Survivors -= 1;
                                        Deaths += 1;
                                        break;
                                    }
                            }
                            Console.ForegroundColor = ConsoleColor.DarkGreen;
                        }
                    }


                    //Displays name of the game
                    Console.WriteLine("            _____                  _                      ");
                    Console.WriteLine("           /  ___|                (_)                     ");
                    Console.WriteLine("           \\ `--. _   _ _ ____   _____   _____  _ __ ___  ");
                    Console.WriteLine("            `--. \\ | | | '__\\ \\ / / \\ \\ / / _ \\| '__/ __|");
                    Console.WriteLine("           /\\__/ / |_| | |   \\ V /| |\\ V / (_) | |  \\__ \\ ");
                    Console.WriteLine("           \\____/ \\__,_|_|    \\_/ |_| \\_/ \\___/|_|  |___/ ");

                    //Starting conditions 
                    Console.WriteLine("\n\n\nWeek: " + Weeks + ".");
                    Console.WriteLine("Survivors: " + Survivors + ".");
                    Console.WriteLine("Resources: " + Resources + ".");
                    Console.WriteLine("Anti Radiation kits: " + AntiRadKits + ".");
                    Console.WriteLine("Resources lost due to raiders: " + LostResources + ".");
                    Console.WriteLine("Resources found: " + FoundResources + ".");
                    Console.WriteLine("People found: " + FoundPeople + ".");
                    Console.WriteLine("People lost: " + PeopleLost + ".\n\n\n");
                    FoundResources = 0;
                    //List of methods to be called
                    TestResourceFeed();
                    TestPopExplore();
                    TestAntiRad();

                    //Setting 3 variables to false 
                    bTestPopExplore = false;
                    bTestResourceFeed = false;
                    bTestAntiRad = false;

                    //List of methods to be called
                    rDeath(TeamAmount);
                    rResources(TeamAmount / 2);
                    rRadiationPlume();


                    if (Deaths >= 1)    //Results of rDeath
                    {
                        Console.WriteLine("You have unfortunately lost " + Deaths + " people whilst exploring");
                        Survivors = Survivors - Deaths; //Removes amount of people who died
                    }

                    //Results of rResources
                    Console.WriteLine("Your exploring has found " + FoundResources + " resources.\nYour exploring has also found " + FoundPeople + " people");
                    Survivors += FoundPeople;   //Add people found why scanvaging 
                    Resources += FoundResources;    //Adds resources found to resources

                    if (bRadationPlume == true) //If the people posability from rRadiationPlume came back True
                    {
                        RadationStoryLine(); //Begins the Radiation random event 
                    }


                    Weeks++;    //Adds one number to weeks

                    if (Weeks >= 10) // if over 10 weeks,
                    {
                        Game_Over(3); //Tells Game_Over what ending message to play
                    }
                }

                catch (Exception) //If unknown errors occur this will happen
                {
                    Game_Over(4);   //Tells Game_Over what ending message to play
                }
            }
        }

        private static void RadationStoryLine()
        {

            //Displays message
            Console.WriteLine("\n\n\n");
            Console.WriteLine("█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗");
            Console.WriteLine("╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝ ");
            Console.WriteLine("                                                                       ");
            Console.WriteLine("                                                                        ");
            Console.WriteLine("                                                                        ");
            Console.WriteLine("██╗    ██╗ █████╗ ██████╗ ███╗   ██╗██╗███╗   ██╗ ██████╗                ");
            Console.WriteLine("██║    ██║██╔══██╗██╔══██╗████╗  ██║██║████╗  ██║██╔════╝                ");
            Console.WriteLine("██║ █╗ ██║███████║██████╔╝██╔██╗ ██║██║██╔██╗ ██║██║  ███╗               ");
            Console.WriteLine("██║███╗██║██╔══██║██╔══██╗██║╚██╗██║██║██║╚██╗██║██║   ██║              ");
            Console.WriteLine("╚███╔███╔╝██║  ██║██║  ██║██║ ╚████║██║██║ ╚████║╚██████╔╝              ");
            Console.WriteLine(" ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝╚═╝  ╚═══╝ ╚═════╝               ");
            Console.WriteLine("                                                                        ");
            Console.WriteLine("██████╗  █████╗ ██████╗ ██╗ █████╗ ████████╗██╗ ██████╗ ███╗   ██╗      ");
            Console.WriteLine("██╔══██╗██╔══██╗██╔══██╗██║██╔══██╗╚══██╔══╝██║██╔═══██╗████╗  ██║      ");
            Console.WriteLine("██████╔╝███████║██║  ██║██║███████║   ██║   ██║██║   ██║██╔██╗ ██║      ");
            Console.WriteLine("██╔══██╗██╔══██║██║  ██║██║██╔══██║   ██║   ██║██║   ██║██║╚██╗██║      ");
            Console.WriteLine("██║  ██║██║  ██║██████╔╝██║██║  ██║   ██║   ██║╚██████╔╝██║ ╚████║      ");
            Console.WriteLine("╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚═╝╚═╝  ╚═╝   ╚═╝   ╚═╝ ╚═════╝ ╚═╝  ╚═══╝      ");
            Console.WriteLine("                                                                        ");
            Console.WriteLine("██████╗ ███████╗████████╗███████╗ ██████╗████████╗███████╗██████╗       ");
            Console.WriteLine("██╔══██╗██╔════╝╚══██╔══╝██╔════╝██╔════╝╚══██╔══╝██╔════╝██╔══██╗      ");
            Console.WriteLine("██║  ██║█████╗     ██║   █████╗  ██║        ██║   █████╗  ██║  ██║    ");
            Console.WriteLine("██║  ██║██╔══╝     ██║   ██╔══╝  ██║        ██║   ██╔══╝  ██║  ██║      ");
            Console.WriteLine("██████╔╝███████╗   ██║   ███████╗╚██████╗   ██║   ███████╗██████╔╝      ");
            Console.WriteLine("╚═════╝ ╚══════╝   ╚═╝   ╚══════╝ ╚═════╝   ╚═╝   ╚══════╝╚═════╝       ");
            Console.WriteLine("                                                                        ");
            Console.WriteLine("                                                                        ");
            Console.WriteLine("                                                                        ");
            Console.WriteLine("█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗");
            Console.WriteLine("╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝");
            Console.WriteLine("\n\n\n");

            Random rProbability = new Random(); //Generates new random value
            int Probability = rProbability.Next(1, 2);  //Generates a 50/50 chance
            int survivorsInfected = 0;

            //Used to determine how many people are affected by radaition 
            switch (Probability)
            {
                //10th populas + 1 
                case 1:
                    {
                        survivorsInfected = (int)((Survivors / 10) + 1); //At least 1 person will be infected, with 10% of pop
                        break;
                    }
                //30th populas + 3
                case 2:
                    {
                        survivorsInfected = (int)((Survivors / 10) * 3) + 3; //at least 3 people will be infected, with chance of 30%
                        break;
                    }
            }

            if (survivorsInfected > Survivors) //if pop is lower than the amount infected, all become infected
            {
                survivorsInfected = Survivors;
            }

            int PeopleToCure = 0;

            //This loop handles the how many people the player wishes to cure
            while (true)
            {
                Console.WriteLine("A radiation plume has cause " + survivorsInfected + " people to fall ill");
                Console.WriteLine("You need a RadKit for each people who are infected, or they will die");
                Console.WriteLine("Each person requires 1 anti rad kit");
                Console.WriteLine("How many people do you wish to save?");
                Console.WriteLine("You currently own " + AntiRadKits + " kits");
                if (int.TryParse(Console.ReadLine(), out PeopleToCure))
                {
                    if (PeopleToCure > AntiRadKits || PeopleToCure < 0)     //if no resources or entered a negative value
                    {
                        Console.WriteLine("You do not own these resources");
                        Console.WriteLine("Please try again");
                    }
                    if (PeopleToCure > survivorsInfected)   //If they are trying to cure too many people
                    {
                        Console.WriteLine("You are trying to cure too many people");

                    }
                    if (PeopleToCure < 0)
                    {
                        Console.WriteLine("You cannot enter minus values.\n");
                    }
                    else //Runs if theres no issues with inputs
                    {
                        survivorsInfected = survivorsInfected - PeopleToCure;   //works out how many people are to die
                        Console.WriteLine("You have decided to save " + PeopleToCure + " people");
                        Console.WriteLine("You have sadly lost " + survivorsInfected + " people.\nWe will morn, but not today");
                        Survivors = Survivors - survivorsInfected;
                        AntiRadKits = AntiRadKits - PeopleToCure;
                        break;
                    }
                    if (Survivors <= 0)
                    {
                        Game_Over(5);
                    }


                }
            }
        }    //This methods handles if the population is affected by radiation poisioning

        private static void TestAntiRad()
        {
            while (!bTestAntiRad) //While false
            {
                Console.WriteLine("How many Anti Radiation Kits do you want to build?: \n1 kit takes 100 resources.\n");

                int RadKits;
                int ResourcesNeeded;

                if (Int32.TryParse(Console.ReadLine(), out RadKits))
                {
                    ResourcesNeeded = RadKits * 100;    //Calcuates resources needed to make radiation kits
                    if (ResourcesNeeded > Resources)
                    {
                        Console.WriteLine("You do not own enough resources to do this\n");    //If user doesnt own enough they will have to reenter value
                        bTestAntiRad = false;
                    }
                    if (ResourcesNeeded < 0) //if entered a negative value
                    {
                        Console.WriteLine("This is a negative value.\n");
                        bTestAntiRad = false;
                    }
                    if (ResourcesNeeded <= Resources && ResourcesNeeded >= 0)
                    {
                        Resources = Resources - ResourcesNeeded; //If they have enough values they will create the kits and resources will be taken off
                        AntiRadKits += RadKits;
                        bTestAntiRad = true;
                    }
                }

            }
        }   //This method handles if the user wishes to create radiation packs

        private static void TestPopExplore()
        {
            while (bTestPopExplore == false)
            {
                Console.WriteLine("How many searching teams do you wish to send?\nEach team takes 2 people");
                Console.WriteLine("Beware, at least 1 person must remain in base");
                Console.WriteLine("Please type team quantity, not people quantity\n");

                if (Int32.TryParse(Console.ReadLine(), out TeamAmount))
                {
                    if (TeamAmount * 50 <= Resources)
                    {

                        TeamAmount *= 2;
                        if (TeamAmount > Survivors) //If you are trying to send out more people than you have
                        {
                            Console.WriteLine("You do not have that many people.\nTry Again\n\n");
                            bTestPopExplore = false;
                            Console.WriteLine("You do not have enough resources to commit to this mission, please reselect\n");   //If none of above are true then question is repeated

                        }
                        if (TeamAmount < 0)     //If you have entered a negative value
                        {
                            Console.WriteLine("You cannot have negative values\nPlease try again\n\n");
                            bTestPopExplore = false;
                            Console.WriteLine("You do not have enough resources to commit to this mission, please reselect\n");   //If none of above are true then question is repeated

                        }
                        if (TeamAmount == Survivors)       //if you are selecting as many teams as you have suvivors 
                        {
                            bGamePlay = false;
                            Console.WriteLine("Raiders raided your bunker.\nEverything is gone\n\n");
                            bTestPopExplore = false;
                            Game_Over(1);   //Game over condition 1
                            Console.WriteLine("You do not have enough resources to commit to this mission, please reselect\n");   //If none of above are true then question is repeated

                        }
                        if (TeamAmount < Survivors && TeamAmount >= 0)      //If your input is possible 
                        {
                            bTestPopExplore = true;
                            Resources = Resources - (TeamAmount / 2) * 50;
                            Console.WriteLine("New resource amount: " + Resources + ".");
                            Console.WriteLine("You have chosen to send " + TeamAmount + ".");
                            Console.WriteLine("But what will they discover, or will they even return?\n\n");
                        }
                    }

                }
            }
        }   //This method handles how many people the player wishes to send out to hunt resoruces

        private static void TestResourceFeed()  //This is the method to handle the feeding of the population
        {
            while (bTestResourceFeed == false)  //Loops that keeps repeating until a true values is entered
            {
                Console.WriteLine("How many resources do you want to feed the group? :\nRequirements for life: 100 per person\n");
                int ResourcesRequired;
                if (Int32.TryParse(Console.ReadLine(), out ResourcesRequired))
                {
                    if (ResourcesRequired > Resources || ResourcesRequired < 0) //This happens when an invalid input is given
                    {
                        bTestResourceFeed = false;
                        Console.WriteLine("You do not have that many resources or you have entered a minus value.\nPlease try again.\n\n");
                    }
                    else        //If a valid input is given then this happens
                    {
                        int PopulationToSurvive = ResourcesRequired / 100;  //This value will soon become the surviving population
                        Survivors = PopulationToSurvive;                    //New population is set

                        bTestResourceFeed = true;                           //Loop ended

                        Resources -= ResourcesRequired;                     //Resources to keep population alive is removed
                        Console.WriteLine("\nResources remaining: " + Resources + ".\n\n");
                        if (Survivors == 0)                                 //If no one survied game is ended
                        {
                            Game_Over(2);
                        }
                    }
                }
            }
        }

        private static void rDeath(int a)   //handles random death events 
        {
            Deaths = 0;
            Random rProbability = new Random();
            for (int i = 0; i != a; i++)
            {

                int Probability = rProbability.Next(1, 100);
                if (Probability <= 20)//20 percent chance of this happening
                {
                    Deaths += 1;
                }
                if (Probability >= 20 && Probability < 30)//5 percent chance of this happening 
                {
                    Deaths += 2;
                }
                else
                {
                    Deaths = 0;                     //No deaths
                }
            }

        }

        private static void rResources(int a)      //Handles resources found in the scavanges
        {
            FoundPeople = 0;
            Random rProbability = new Random(); //Creates new random object
            if (a != 0)
            {
                for (int i = 0; i <= a; i++)
                {
                    int Probability = rProbability.Next(1, 100);    //Generates a number between 1 and 100
                    if (Probability <= 3) //5 Percent loot
                    {
                        //Massive loot find
                        FoundResources += 30;
                        FoundPeople += 2;

                    }
                    if (Probability > 5 && Probability <= 25) //20 percent 
                    {
                        //Finding one person + basic loot
                        FoundPeople = 2;
                        FoundResources += 200;

                    }
                    if (Probability > 25 && Probability <= 50) //15 Percent chance
                    {
                        //Find nothing

                    }
                    else //60 chance
                    {
                        //Finding basic loot
                        FoundResources += 100;

                    }

                }
            }
            else
            {
                FoundResources = 0;
            }

            
            
        }
        
        private static void rRadiationPlume()
        {
            Random rProabaility = new Random();     //Generates new random object
            int Probability = rProabaility.Next(1, 100);
            if (Probability <= 15)      //15% chance 
            {
                bRadationPlume = true;
            }
            else
            {
                bRadationPlume = false;
            }
        }   //Handles the probability of the radiation event
         
        private static void Game_Over(int Reason)
        {
            switch (Reason)
            {
                case 1:             //Game over condition 1 - Too many people sent on raiding missions
                    Console.WriteLine("Everything is gone.");
                    Console.WriteLine("Raiders took everything.");
                    Console.WriteLine("There was no one here to defend the supplies.");
                    Console.WriteLine("There is nothing left to do. This is the end.");
                    //All resources, AR kits, and people are set to 0
                    Survivors = 0;
                    Resources = 0;
                    AntiRadKits = 0;
                    break;
                case 2:           //Game over condition 2 - Population not fed enough
                    Console.WriteLine("You failed to sufficently feed your population.");
                    Console.WriteLine("How could you of done this??");
                    Survivors = 0;
                    break;
                case 3:          //Game over condition 3 - Survived 10 weeks
                    Console.WriteLine("Congratulations!");
                    Console.WriteLine("Rescue has arrived!");
                    Console.WriteLine("You and " + (Survivors - 1) + " survived 10 weeks.");
                    break;
               
                case 4:         //Game ocer condition 4 - An unknown error has occurred 
                    Console.WriteLine("AN ERROR HAS OCCURED");
                    Console.WriteLine("PLEASE RESTART PROGRAM");
                    break;
                case 5:         //Game over condition 5 - all pop dies due to radiation story line
                    Console.WriteLine("Your population has all died due to radiation.");
                    Survivors = 0;
                    break;
            }
            //Displays all rasources, people, and AR kits 
            Console.WriteLine("Remaning:");
            Console.WriteLine("Population: " + Survivors);
            Console.WriteLine("Resources: " + Resources);
            Console.WriteLine("Anti Radiation Kits: " + AntiRadKits);
            Pause(5);
            Console.SetWindowSize(100, 20);

            Console.WriteLine("  _______      ___      .___  ___.  _______      ______   ____    ____  _______ .______      ");
            Console.WriteLine("/  _____|    /   \\     |   \\/   | |   ____|    /  __  \\  \\   \\  /   / |   ____||   _  \\     ");
            Console.WriteLine("|  |  __     /  ^  \\    |  \\  /  | |  |__      |  |  |  |  \\   \\/   /  |  |__   |  |_)  |    ");
            Console.WriteLine("|  | |_ |   /  /_\\  \\   |  |\\/|  | |   __|     |  |  |  |   \\      /   |   __|  |      /    ");
            Console.WriteLine("|  |__| |  /  _____  \\  |  |  |  | |  |____    |  `--'  |    \\    /    |  |____ |  |\\  \\----.");
            Console.WriteLine("\\______| /__/     \\__\\ |__|  |__| |_______|    \\______/      \\__/     |_______|| _| `._____|");

            //ends main game loop
            bGamePlay = false;
            Console.ReadLine();
        }   //Method for generating the game ending scene

        private static void Pause(float Seconds)
        {
            Timer time = new Timer(Seconds * 60);
            time.Start();
        }   //Used to create a delay in code
    }
}